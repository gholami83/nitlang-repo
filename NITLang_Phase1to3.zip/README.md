# NITLang (Phases 1-3)
A simple educational language built in Python.

## Features
- Arithmetic expressions (+, -, *, /)
- Variables (let)
- Basic scope (Environment)

## Run
```bash
python main.py
```
